<link rel="stylesheet" href="../MVC/Content/css/Footer.css">
<footer>

    <div class="footer-contenu">

      <div class="footer-contacte">
        <h3>Nous contacter</h3>
        <ul class="liste-contacte">
          <li>99 Av. Jean Baptiste Clément</li>
          <li>93430 Villetaneuse</li>
          <li>06 58 30 11 95</li>
          <li>bde.iut.villetaneuse@gmail.com</li>
        </ul>
      </div>

      <div class="footer-reseau">
        <h3> Réseaux sociaux </h3>
        <ul class="liste-reseau">
          <li><a href="https://www.instagram.com/bdeup13/%22%3E"> <img src="../MVC/Content/img/instagram.svg" class="insta" alt="logo istagram"></a></li>
          <li><a href="https://www.tiktok.com/@bdeup13?_t=8XeqIcUP8XF&_r=1&fbclid=PAAaZ_noPD2puYIRo487qGeJtzZwcnzErIxAWR9LAVAhEGcoxbvmwk3WS5_f0%22%3E"><img src="../MVC/Content/img/tiktok.svg" class="tiktok" alt="logo tiktok"></a></li>
        </ul>
      </div>

      <div class="footer-document">
        <h3> Documents offciels </h3>
        <ul class="liste-document">
          <li><a href="../MVC/Content/html/MentionLegal.html"> Mention légales </a></li>
          <li><a href="../MVC/Content/html/Charte.html"> Charte </a></li>
        </ul>
      </div> 


    </div>

    <div class="ah">
    <h1 class='copyright'>Copyright&#169;Stark Industries</h1> 
  </div>



  </footer>