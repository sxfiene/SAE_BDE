

<h1> 
    <?php echo $title; ?>
</h1>

<p>   
    <?php echo $message; ?>
</p>


