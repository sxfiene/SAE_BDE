
  $(".menuderoulant").hide();

  $(document).ready(function() {

  $('.menubouton').click(function() {

  $('.menuderoulant').slideToggle();});
   });